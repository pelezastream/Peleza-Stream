import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:offline_ai/controllers/offline_ai_controller.dart';
import 'package:offline_ai/main.dart';
import 'package:offline_ai/screens/chat_screen.dart';
import 'package:provider/provider.dart';

void main() {
  testWidgets('shows the Offline AI shell while starting', (
    WidgetTester tester,
  ) async {
    final controller = OfflineAiController();
    await tester.pumpWidget(
      ChangeNotifierProvider<OfflineAiController>.value(
        value: controller,
        child: OfflineAiApp(controller: controller),
      ),
    );

    expect(find.text('Offline AI'), findsOneWidget);
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
  });

  testWidgets('does not load images embedded in model Markdown', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: OfflineMarkdownBody(
            data: '![tracking pixel](https://example.com/pixel.png)',
          ),
        ),
      ),
    );

    expect(find.byType(Image), findsNothing);
    expect(find.text('[Image omitted: tracking pixel]'), findsOneWidget);
  });
}
