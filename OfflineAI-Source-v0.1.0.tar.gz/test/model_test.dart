import 'package:flutter_test/flutter_test.dart';
import 'package:offline_ai/models/conversation.dart';
import 'package:offline_ai/models/local_model.dart';

void main() {
  test('conversation JSON round-trips messages', () {
    final now = DateTime.utc(2026, 10, 12);
    final original = Conversation(
      id: 'conversation-1',
      title: 'Offline test',
      createdAt: now,
      updatedAt: now,
      messages: <ChatMessage>[
        ChatMessage(
          id: 'message-1',
          role: MessageRole.user,
          text: 'Hello',
          createdAt: now,
        ),
      ],
    );

    final restored = Conversation.fromJson(original.toJson());
    expect(restored.title, 'Offline test');
    expect(restored.messages.single.text, 'Hello');
    expect(restored.messages.single.role, MessageRole.user);
  });

  test('catalog has phone and desktop quality tiers', () {
    expect(modelCatalog, hasLength(greaterThanOrEqualTo(3)));
    expect(modelCatalog.any((model) => !model.desktopOnly), isTrue);
    expect(modelCatalog.any((model) => model.desktopOnly), isTrue);
    expect(
      modelCatalog.map((model) => model.id).toSet(),
      hasLength(modelCatalog.length),
    );
  });
}
