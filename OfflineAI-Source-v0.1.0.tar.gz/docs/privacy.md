# Privacy

Offline AI stores conversations and downloaded model files in the app's local
data directory. Prompts and responses are passed only to the inference runtime
inside the process. The app has no analytics, advertising, account, telemetry,
or cloud inference code.

Internet access is used only when the user chooses to download a model. The
Android application disables backup and cleartext network traffic. The macOS
sandbox allows outbound network access so model downloads work.

Deleting a conversation removes its local record. Deleting a model removes its
managed cached file. Device backups, disk encryption, and secure deletion are
controlled by the operating system; the app does not claim its local database
is independently encrypted. On Windows, model files use LocalAppData so they
do not enter a roaming profile. The operating system or an administrator can
still sync the small preferences store that contains conversations.

