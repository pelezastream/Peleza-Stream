# Architecture

Offline AI uses Flutter for one Android and desktop interface and `llamadart`
for llama.cpp-backed GGUF inference. Native inference runs inside the app; no
local server or cloud service is required.

`OfflineAiController` owns one inference engine and one active chat session.
Keeping one loaded model avoids competing for device RAM. Conversation records
are serialized locally through shared preferences, while model files and their
cache metadata live in the application support directory. Windows keeps model
files under LocalAppData to avoid placing multi-gigabyte files in a roaming
profile.

The model manager downloads to a partial file, resumes supported transfers,
and promotes a file only after completion. Catalog entries can pin a SHA-256;
the balanced model currently does. Model URLs should move to immutable
revisions with published hashes as those become available.

The app deliberately keeps remote tools out of the first release. Its system
prompt tells the model that it has no live internet data. A later documents
feature can add local retrieval without changing the inference boundary.

## Release gates

1. Static analysis and unit/widget tests pass.
2. Android arm64 and all three desktop packages compile in CI.
3. A real model loads and answers after the device restarts with networking
   disabled.
4. Stop and regenerate work repeatedly without retaining extra model copies.
5. Corrupt or incomplete model downloads fail visibly and can resume or retry.
6. Installers are signed, checksummed, and accompanied by dependency and model
   license notices.

