import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'controllers/offline_ai_controller.dart';
import 'screens/chat_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = OfflineAiController();
  runApp(
    ChangeNotifierProvider<OfflineAiController>.value(
      value: controller,
      child: OfflineAiApp(controller: controller),
    ),
  );
  unawaited(controller.initialize());
}

class OfflineAiApp extends StatefulWidget {
  const OfflineAiApp({required this.controller, super.key});

  final OfflineAiController controller;

  @override
  State<OfflineAiApp> createState() => _OfflineAiAppState();
}

class _OfflineAiAppState extends State<OfflineAiApp> {
  late final AppLifecycleListener _lifecycle = AppLifecycleListener(
    onExitRequested: () async {
      await widget.controller.close();
      return AppExitResponse.exit;
    },
  );

  @override
  void dispose() {
    _lifecycle.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final darkScheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF6C63FF),
      brightness: Brightness.dark,
      surface: const Color(0xFF111218),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Offline AI',
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: darkScheme,
        scaffoldBackgroundColor: const Color(0xFF0B0C10),
        cardTheme: const CardThemeData(
          elevation: 0,
          color: Color(0xFF171920),
          margin: EdgeInsets.zero,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF171920),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const ChatScreen(),
    );
  }
}
