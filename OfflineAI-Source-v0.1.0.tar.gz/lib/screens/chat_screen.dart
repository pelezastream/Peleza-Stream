import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'package:provider/provider.dart';

import '../controllers/offline_ai_controller.dart';
import '../models/conversation.dart';
import 'model_library_sheet.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _composer = TextEditingController();
  final ScrollController _scroll = ScrollController();

  @override
  void dispose() {
    _composer.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send(OfflineAiController controller) {
    final text = _composer.text.trim();
    if (text.isEmpty) return;
    _composer.clear();
    controller.send(text);
  }

  void _openModels(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: const Color(0xFF111218),
      builder: (BuildContext context) => const ModelLibrarySheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<OfflineAiController>(
      builder: (BuildContext context, OfflineAiController controller, _) {
        final wide = MediaQuery.sizeOf(context).width >= 860;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scroll.hasClients && controller.generating) {
            _scroll.animateTo(
              _scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 120),
              curve: Curves.easeOut,
            );
          }
        });

        return Scaffold(
          drawer: wide ? null : Drawer(child: _ConversationSidebar(controller)),
          appBar: AppBar(
            title: const Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(Icons.auto_awesome, size: 21),
                SizedBox(width: 10),
                Text('Offline AI'),
              ],
            ),
            actions: <Widget>[
              TextButton.icon(
                onPressed: () => _openModels(context),
                icon: Icon(
                  controller.modelReady
                      ? Icons.memory
                      : Icons.download_for_offline_outlined,
                  size: 19,
                ),
                label: Text(
                  controller.activeModel?.name.split(' · ').first ?? 'Models',
                ),
              ),
              const SizedBox(width: 8),
            ],
          ),
          body: Row(
            children: <Widget>[
              if (wide) ...<Widget>[
                SizedBox(width: 280, child: _ConversationSidebar(controller)),
                const VerticalDivider(width: 1),
              ],
              Expanded(
                child: _ChatPane(
                  controller: controller,
                  composer: _composer,
                  scroll: _scroll,
                  onSend: () => _send(controller),
                  onOpenModels: () => _openModels(context),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ConversationSidebar extends StatelessWidget {
  const _ConversationSidebar(this.controller);

  final OfflineAiController controller;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xFF101116),
      child: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 16, 12, 10),
              child: FilledButton.icon(
                onPressed: controller.generating
                    ? null
                    : () {
                        controller.newConversation();
                        if (Scaffold.maybeOf(context)?.isDrawerOpen ?? false) {
                          Navigator.pop(context);
                        }
                      },
                icon: const Icon(Icons.add),
                label: const Text('New conversation'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: controller.conversations.length,
                itemBuilder: (BuildContext context, int index) {
                  final conversation = controller.conversations[index];
                  final selected =
                      conversation.id == controller.activeConversation?.id;
                  return ListTile(
                    selected: selected,
                    selectedTileColor: Theme.of(
                      context,
                    ).colorScheme.primaryContainer.withValues(alpha: 0.35),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    leading: const Icon(Icons.chat_bubble_outline, size: 19),
                    title: Text(
                      conversation.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    onTap: controller.generating
                        ? null
                        : () {
                            controller.selectConversation(conversation.id);
                            if (Scaffold.maybeOf(context)?.isDrawerOpen ??
                                false) {
                              Navigator.pop(context);
                            }
                          },
                    trailing: PopupMenuButton<String>(
                      iconSize: 18,
                      onSelected: (String value) {
                        if (value == 'rename') {
                          _rename(context, controller, conversation);
                        } else if (value == 'delete') {
                          controller.deleteConversation(conversation.id);
                        }
                      },
                      itemBuilder: (_) => const <PopupMenuEntry<String>>[
                        PopupMenuItem(value: 'rename', child: Text('Rename')),
                        PopupMenuItem(value: 'delete', child: Text('Delete')),
                      ],
                    ),
                  );
                },
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                children: <Widget>[
                  Icon(Icons.lock_outline, size: 16),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Chats stay on this device',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _rename(
    BuildContext context,
    OfflineAiController controller,
    Conversation conversation,
  ) async {
    final input = TextEditingController(text: conversation.title);
    final result = await showDialog<String>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Rename conversation'),
        content: TextField(controller: input, autofocus: true),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, input.text),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    input.dispose();
    if (result != null) {
      await controller.renameConversation(conversation.id, result);
    }
  }
}

class _ChatPane extends StatelessWidget {
  const _ChatPane({
    required this.controller,
    required this.composer,
    required this.scroll,
    required this.onSend,
    required this.onOpenModels,
  });

  final OfflineAiController controller;
  final TextEditingController composer;
  final ScrollController scroll;
  final VoidCallback onSend;
  final VoidCallback onOpenModels;

  @override
  Widget build(BuildContext context) {
    if (!controller.initialized) {
      return const Center(child: CircularProgressIndicator());
    }

    return Column(
      children: <Widget>[
        if (controller.error case final error?)
          MaterialBanner(
            content: Text(error),
            leading: const Icon(Icons.error_outline),
            actions: <Widget>[
              TextButton(
                onPressed: controller.clearError,
                child: const Text('Dismiss'),
              ),
            ],
          ),
        if (controller.loadingModel)
          const LinearProgressIndicator(minHeight: 2),
        Expanded(
          child: controller.messages.isEmpty
              ? _Welcome(
                  onOpenModels: onOpenModels,
                  ready: controller.modelReady,
                )
              : _MessageList(controller: controller, scroll: scroll),
        ),
        _Composer(
          controller: controller,
          textController: composer,
          onSend: onSend,
          onOpenModels: onOpenModels,
        ),
      ],
    );
  }
}

class _Welcome extends StatelessWidget {
  const _Welcome({required this.onOpenModels, required this.ready});

  final VoidCallback onOpenModels;
  final bool ready;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                width: 74,
                height: 74,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Icon(Icons.auto_awesome, size: 38),
              ),
              const SizedBox(height: 24),
              Text(
                ready ? 'How can I help?' : 'Your private, offline assistant',
                style: Theme.of(context).textTheme.headlineMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              Text(
                ready
                    ? 'Ask a question below. Replies are generated on this device.'
                    : 'Download an AI model once, then chat without Wi-Fi, mobile data, an account, or a cloud API.',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
                textAlign: TextAlign.center,
              ),
              if (!ready) ...<Widget>[
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: onOpenModels,
                  icon: const Icon(Icons.download_for_offline_outlined),
                  label: const Text('Choose a model'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _MessageList extends StatelessWidget {
  const _MessageList({required this.controller, required this.scroll});

  final OfflineAiController controller;
  final ScrollController scroll;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      controller: scroll,
      padding: const EdgeInsets.fromLTRB(18, 24, 18, 32),
      itemCount: controller.messages.length,
      itemBuilder: (BuildContext context, int index) {
        final message = controller.messages[index];
        final last = index == controller.messages.length - 1;
        return _MessageBubble(
          message: message,
          showRegenerate: last && !message.isUser && !controller.generating,
          onRegenerate: controller.regenerateLastReply,
        );
      },
    );
  }
}

/// Renders model output without resolving Markdown images from the network or
/// the local file system.
class OfflineMarkdownBody extends StatelessWidget {
  const OfflineMarkdownBody({required this.data, super.key});

  final String data;

  @override
  Widget build(BuildContext context) {
    return MarkdownBody(
      data: data,
      selectable: true,
      softLineBreak: true,
      imageBuilder: (Uri uri, String? title, String? alt) {
        final description = alt?.trim();
        return Text(
          description == null || description.isEmpty
              ? '[Image omitted]'
              : '[Image omitted: $description]',
          style: Theme.of(
            context,
          ).textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic),
        );
      },
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({
    required this.message,
    required this.showRegenerate,
    required this.onRegenerate,
  });

  final ChatMessage message;
  final bool showRegenerate;
  final VoidCallback onRegenerate;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Align(
      alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 780),
        child: Padding(
          padding: const EdgeInsets.only(bottom: 18),
          child: Column(
            crossAxisAlignment: message.isUser
                ? CrossAxisAlignment.end
                : CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 13,
                ),
                decoration: BoxDecoration(
                  color: message.isUser
                      ? colorScheme.primaryContainer
                      : const Color(0xFF171920),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: message.text.isEmpty
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : message.isUser
                    ? SelectableText(message.text)
                    : OfflineMarkdownBody(data: message.text),
              ),
              if (!message.isUser && message.text.isNotEmpty)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    IconButton(
                      tooltip: 'Copy',
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.copy_outlined, size: 18),
                      onPressed: () =>
                          Clipboard.setData(ClipboardData(text: message.text)),
                    ),
                    if (showRegenerate)
                      IconButton(
                        tooltip: 'Regenerate',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.refresh, size: 19),
                        onPressed: onRegenerate,
                      ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Composer extends StatelessWidget {
  const _Composer({
    required this.controller,
    required this.textController,
    required this.onSend,
    required this.onOpenModels,
  });

  final OfflineAiController controller;
  final TextEditingController textController;
  final VoidCallback onSend;
  final VoidCallback onOpenModels;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 850),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              Expanded(
                child: TextField(
                  controller: textController,
                  enabled: controller.modelReady && !controller.generating,
                  minLines: 1,
                  maxLines: 6,
                  textInputAction: TextInputAction.newline,
                  decoration: InputDecoration(
                    hintText: controller.modelReady
                        ? 'Message Offline AI'
                        : 'Choose a model to start chatting',
                  ),
                  onSubmitted: (_) {
                    if (!Platform.isAndroid) onSend();
                  },
                ),
              ),
              const SizedBox(width: 8),
              if (controller.generating)
                IconButton.filled(
                  tooltip: 'Stop',
                  onPressed: controller.stopGeneration,
                  icon: const Icon(Icons.stop),
                )
              else
                IconButton.filled(
                  tooltip: controller.modelReady ? 'Send' : 'Choose model',
                  onPressed: controller.modelReady ? onSend : onOpenModels,
                  icon: Icon(
                    controller.modelReady
                        ? Icons.arrow_upward
                        : Icons.download_for_offline_outlined,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
