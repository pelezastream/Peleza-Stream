import 'dart:io';

import 'package:flutter/material.dart';
import 'package:llamadart/llamadart.dart';
import 'package:provider/provider.dart';

import '../controllers/offline_ai_controller.dart';
import '../models/local_model.dart';

class ModelLibrarySheet extends StatelessWidget {
  const ModelLibrarySheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<OfflineAiController>(
      builder: (BuildContext context, OfflineAiController controller, _) {
        return FractionallySizedBox(
          heightFactor: 0.92,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              automaticallyImplyLeading: false,
              title: const Text('Choose your AI model'),
              actions: <Widget>[
                IconButton(
                  tooltip: 'Close',
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            body: ListView(
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 32),
              children: <Widget>[
                Text(
                  'Larger models usually give better answers but need more RAM '
                  'and storage. Download happens once; chat remains offline.',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 18),
                for (final model in modelCatalog)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _ModelCard(model: model, controller: controller),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ModelCard extends StatelessWidget {
  const _ModelCard({required this.model, required this.controller});

  final LocalModel model;
  final OfflineAiController controller;

  @override
  Widget build(BuildContext context) {
    final installed = controller.isInstalled(model);
    final active = controller.activeModel?.id == model.id;
    final downloading = controller.downloadingModel?.id == model.id;
    final unavailable = model.desktopOnly && Platform.isAndroid;
    final progress = downloading ? controller.download.fraction : null;
    final busy =
        controller.loadingModel ||
        controller.generating ||
        controller.download.isRunning;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    model.name,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
                if (active)
                  const Chip(
                    avatar: Icon(Icons.check_circle, size: 16),
                    label: Text('Active'),
                  )
                else if (installed)
                  const Chip(label: Text('Installed')),
              ],
            ),
            const SizedBox(height: 8),
            Text(model.description),
            const SizedBox(height: 13),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                _Spec(icon: Icons.storage_outlined, label: model.sizeLabel),
                _Spec(
                  icon: Icons.memory_outlined,
                  label: '${model.minRamGb} GB RAM+',
                ),
                if (model.desktopOnly)
                  const _Spec(icon: Icons.computer, label: 'Desktop only'),
                _Spec(icon: Icons.gavel_outlined, label: model.license),
              ],
            ),
            if (downloading) ...<Widget>[
              const SizedBox(height: 16),
              LinearProgressIndicator(value: progress),
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  Expanded(child: Text(_downloadLabel(controller.download))),
                  if (controller.download.isRunning)
                    TextButton(
                      onPressed: controller.cancelDownload,
                      child: const Text('Cancel'),
                    ),
                ],
              ),
            ] else ...<Widget>[
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  if (installed)
                    TextButton(
                      onPressed: busy ? null : () => _confirmDelete(context),
                      child: const Text('Delete'),
                    ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: unavailable || busy
                        ? null
                        : installed
                        ? active
                              ? null
                              : () => controller.loadModel(model)
                        : () => controller.downloadAndLoad(model),
                    icon: Icon(installed ? Icons.play_arrow : Icons.download),
                    label: Text(
                      unavailable
                          ? 'Desktop only'
                          : active
                          ? 'In use'
                          : installed
                          ? 'Use model'
                          : 'Download',
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: Text('Delete ${model.name}?'),
        content: Text(
          'This removes ${model.sizeLabel} of model data from this device. '
          'You can download it again later.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true) await controller.deleteModel(model);
  }

  String _downloadLabel(ModelDownloadTaskSnapshot snapshot) {
    return switch (snapshot.stage) {
      ModelDownloadTaskStage.resolving => 'Preparing download…',
      ModelDownloadTaskStage.checkingCache => 'Checking local files…',
      ModelDownloadTaskStage.downloading =>
        snapshot.fraction == null
            ? 'Downloading…'
            : 'Downloading ${(snapshot.fraction! * 100).toStringAsFixed(0)}%',
      ModelDownloadTaskStage.verifying => 'Verifying download…',
      ModelDownloadTaskStage.ready => 'Ready',
      ModelDownloadTaskStage.cancelled => 'Download paused',
      ModelDownloadTaskStage.failed => 'Download failed',
      ModelDownloadTaskStage.idle => 'Waiting',
    };
  }
}

class _Spec extends StatelessWidget {
  const _Spec({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Icon(icon, size: 15),
          const SizedBox(width: 6),
          Text(label, style: Theme.of(context).textTheme.labelMedium),
        ],
      ),
    );
  }
}
