import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:llamadart/llamadart.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';

import '../models/conversation.dart';
import '../models/local_model.dart';
import '../services/chat_store.dart';

class OfflineAiController extends ChangeNotifier {
  OfflineAiController({ChatStore? store}) : _store = store ?? ChatStore();

  static const String _systemPrompt =
      'You are a thoughtful, accurate personal assistant running entirely on '
      'the user\'s device. Give clear, direct answers. Use Markdown when it '
      'improves readability. If you are unsure, say so. You have no internet '
      'access and must not claim to know live information.';

  final ChatStore _store;
  final List<Conversation> _conversations = <Conversation>[];
  final Set<String> _installedModelIds = <String>{};

  DefaultModelDownloadManager? _modelManager;
  ModelDownloadController? _downloadController;
  StreamSubscription<ModelDownloadTaskSnapshot>? _downloadSubscription;
  LlamaEngine? _engine;
  ChatSession? _session;
  Conversation? _activeConversation;
  LocalModel? _activeModel;
  LocalModel? _downloadingModel;
  LocalModel? _lastDownloadModel;

  bool _initialized = false;
  bool _loadingModel = false;
  bool _generating = false;
  String? _error;
  ModelDownloadTaskSnapshot _download = const ModelDownloadTaskSnapshot.idle();
  int _idSequence = 0;

  bool get initialized => _initialized;
  bool get loadingModel => _loadingModel;
  bool get generating => _generating;
  bool get modelReady =>
      _activeModel != null && _session != null && (_engine?.isReady ?? false);
  String? get error => _error;
  LocalModel? get activeModel => _activeModel;
  LocalModel? get downloadingModel => _downloadingModel;
  Conversation? get activeConversation => _activeConversation;
  ModelDownloadTaskSnapshot get download => _download;

  List<Conversation> get conversations {
    final sorted = List<Conversation>.from(_conversations)
      ..sort(
        (Conversation a, Conversation b) => b.updatedAt.compareTo(a.updatedAt),
      );
    return List<Conversation>.unmodifiable(sorted);
  }

  List<ChatMessage> get messages =>
      List<ChatMessage>.unmodifiable(_activeConversation?.messages ?? const []);

  bool isInstalled(LocalModel model) => _installedModelIds.contains(model.id);

  Future<void> initialize() async {
    if (_initialized) return;
    try {
      await LlamaLogging.configure(
        level: LlamaLogLevel.warn,
        nativeLevel: LlamaLogLevel.warn,
      );
      final supportDirectory = Platform.isWindows
          ? await getApplicationCacheDirectory()
          : await getApplicationSupportDirectory();
      final modelsDirectory = Directory(
        path.join(supportDirectory.path, 'models'),
      );
      await modelsDirectory.create(recursive: true);

      _modelManager = DefaultModelDownloadManager.appPrivate(
        cacheDirectory: modelsDirectory.path,
      );
      _engine = LlamaEngine(
        LlamaBackend(),
        modelDownloadManager: _modelManager,
      );

      _conversations.addAll(await _store.loadConversations());
      if (_conversations.isEmpty) _createConversation(notify: false);
      _activeConversation = conversations.first;

      for (final model in modelCatalog) {
        final entry = await _modelManager!.get(model.source.cacheKey);
        if (entry != null) _installedModelIds.add(model.id);
      }

      final selectedModelId = await _store.loadSelectedModelId();
      final selectedModel = _findModel(selectedModelId);
      if (selectedModel != null && isInstalled(selectedModel)) {
        await _loadInstalledModel(selectedModel);
      }
    } on Object catch (exception) {
      _error = _friendlyError(exception);
    } finally {
      _initialized = true;
      notifyListeners();
    }
  }

  Conversation _createConversation({bool notify = true}) {
    final now = DateTime.now();
    final conversation = Conversation(
      id: _newId('conversation'),
      title: 'New conversation',
      createdAt: now,
      updatedAt: now,
    );
    _conversations.add(conversation);
    _activeConversation = conversation;
    _rebuildSession();
    unawaited(_persistConversations());
    if (notify) notifyListeners();
    return conversation;
  }

  void newConversation() {
    if (_generating) return;
    _createConversation();
  }

  void selectConversation(String id) {
    if (_generating || _activeConversation?.id == id) return;
    final conversation = _conversations
        .where((Conversation value) => value.id == id)
        .firstOrNull;
    if (conversation == null) return;
    _activeConversation = conversation;
    _rebuildSession();
    notifyListeners();
  }

  Future<void> deleteConversation(String id) async {
    if (_generating) return;
    _conversations.removeWhere((Conversation value) => value.id == id);
    if (_conversations.isEmpty) {
      _createConversation(notify: false);
    } else if (_activeConversation?.id == id) {
      _activeConversation = conversations.first;
    }
    _rebuildSession();
    await _persistConversations();
    notifyListeners();
  }

  Future<void> renameConversation(String id, String title) async {
    final cleaned = title.trim();
    if (cleaned.isEmpty) return;
    final conversation = _conversations
        .where((Conversation value) => value.id == id)
        .firstOrNull;
    if (conversation == null) return;
    conversation
      ..title = cleaned
      ..updatedAt = DateTime.now();
    await _persistConversations();
    notifyListeners();
  }

  Future<void> downloadAndLoad(LocalModel model) async {
    if (_download.isRunning || _loadingModel || _generating) return;
    _error = null;
    _downloadingModel = model;
    _lastDownloadModel = model;
    await _downloadSubscription?.cancel();
    await _downloadController?.dispose();
    _downloadController = ModelDownloadController(manager: _modelManager!);
    _downloadSubscription = _downloadController!.snapshots.listen((
      ModelDownloadTaskSnapshot snapshot,
    ) {
      _download = snapshot;
      notifyListeners();
    });
    notifyListeners();

    try {
      await _downloadController!.start(
        model.source,
        options: ModelLoadOptions(
          sha256: model.sha256,
          resume: true,
          maxRetries: 3,
        ),
      );
      _installedModelIds.add(model.id);
      await _loadInstalledModel(model);
    } on Object catch (exception) {
      if (_download.stage != ModelDownloadTaskStage.cancelled) {
        _error = _friendlyError(exception);
      }
    } finally {
      _downloadingModel = null;
      notifyListeners();
    }
  }

  Future<void> loadModel(LocalModel model) async {
    if (!isInstalled(model) || _loadingModel || _generating) return;
    _error = null;
    try {
      await _loadInstalledModel(model);
    } on Object catch (exception) {
      _error = _friendlyError(exception);
      notifyListeners();
    }
  }

  Future<void> _loadInstalledModel(LocalModel model) async {
    final manager = _modelManager!;
    final entry = await manager.get(model.source.cacheKey);
    if (entry == null) {
      _installedModelIds.remove(model.id);
      throw StateError('The downloaded model file could not be found.');
    }

    _loadingModel = true;
    // setModel unloads the current model before loading the replacement. Clear
    // the session immediately so a failed switch cannot leave stale UI state
    // or accept a prompt against an engine that no longer has a model.
    _activeModel = null;
    _session = null;
    notifyListeners();
    try {
      await _engine!.setModel(
        LlamaModel(ModelSource.path(entry.filePath)),
        params: ModelParams(
          contextSize: model.contextSize,
          gpuLayers: Platform.isAndroid ? 0 : ModelParams.maxGpuLayers,
        ),
      );
      _activeModel = model;
      _rebuildSession();
      await _store.saveSelectedModelId(model.id);
    } finally {
      _loadingModel = false;
      notifyListeners();
    }
  }

  void cancelDownload() => _downloadController?.cancel();

  Future<void> retryDownload() async {
    final model = _lastDownloadModel;
    if (model == null || !_download.canRetry) return;
    await downloadAndLoad(model);
  }

  Future<void> deleteModel(LocalModel model) async {
    if (_generating || _loadingModel || _download.isRunning) return;
    if (_activeModel?.id == model.id) {
      await _engine?.unloadModel();
      _activeModel = null;
      _session = null;
      await _store.saveSelectedModelId(null);
    }
    await _modelManager?.remove(model.source.cacheKey);
    _installedModelIds.remove(model.id);
    notifyListeners();
  }

  Future<void> send(String input) async {
    final text = input.trim();
    final conversation = _activeConversation;
    if (text.isEmpty || conversation == null || !modelReady || _generating) {
      return;
    }

    final now = DateTime.now();
    conversation.messages.add(
      ChatMessage(
        id: _newId('user'),
        role: MessageRole.user,
        text: text,
        createdAt: now,
      ),
    );
    if (conversation.messages.length == 1) {
      conversation.title = _titleFrom(text);
    }
    conversation.updatedAt = now;
    await _persistConversations();
    await _streamReply(text);
  }

  Future<void> regenerateLastReply() async {
    final conversation = _activeConversation;
    if (conversation == null || _generating || !modelReady) return;
    final messages = conversation.messages;
    if (messages.length < 2 || messages.last.isUser) return;
    final user = messages[messages.length - 2];
    if (!user.isUser) return;

    messages.removeLast();
    _rebuildSession(excludeTail: 1);
    await _streamReply(user.text);
  }

  Future<void> _streamReply(String prompt) async {
    final conversation = _activeConversation!;
    final reply = ChatMessage(
      id: _newId('assistant'),
      role: MessageRole.assistant,
      text: '',
      createdAt: DateTime.now(),
    );
    conversation.messages.add(reply);
    _generating = true;
    _error = null;
    notifyListeners();

    try {
      await for (final chunk in _session!.create(
        <LlamaContentPart>[LlamaTextContent(prompt)],
        params: GenerationParams(
          maxTokens: _activeModel!.maxTokens,
          temp: 0.7,
          topK: 20,
          topP: 0.8,
          penalty: 1.05,
        ),
        enableThinking: _activeModel!.supportsThinking,
      )) {
        if (chunk.text.isNotEmpty) {
          reply.text += chunk.text;
          notifyListeners();
        }
      }
      if (reply.text.trim().isEmpty) {
        reply.text = 'I could not produce an answer. Please try again.';
      }
    } on Object catch (exception) {
      if (reply.text.isEmpty) conversation.messages.remove(reply);
      _error = _friendlyError(exception);
    } finally {
      _generating = false;
      conversation.updatedAt = DateTime.now();
      await _persistConversations();
      notifyListeners();
    }
  }

  void stopGeneration() => _engine?.cancelGeneration();

  void clearError() {
    _error = null;
    notifyListeners();
  }

  void _rebuildSession({int excludeTail = 0}) {
    if (_activeModel == null || _activeConversation == null) {
      _session = null;
      return;
    }
    final session = ChatSession(
      _engine!,
      maxContextTokens: _activeModel!.contextSize,
      systemPrompt: _systemPrompt,
    );
    final messages = _activeConversation!.messages;
    final end = (messages.length - excludeTail).clamp(0, messages.length);
    for (final message in messages.take(end)) {
      session.addMessage(
        LlamaChatMessage.fromText(
          role: message.isUser ? LlamaChatRole.user : LlamaChatRole.assistant,
          text: message.text,
        ),
      );
    }
    _session = session;
  }

  Future<void> _persistConversations() =>
      _store.saveConversations(_conversations);

  LocalModel? _findModel(String? id) {
    if (id == null) return null;
    return modelCatalog.where((LocalModel model) => model.id == id).firstOrNull;
  }

  String _newId(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}-${_idSequence++}';

  String _titleFrom(String text) {
    final oneLine = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    return oneLine.length <= 46 ? oneLine : '${oneLine.substring(0, 46)}…';
  }

  String _friendlyError(Object exception) {
    if (exception is LlamaException) return exception.message;
    return exception.toString().replaceFirst(
      RegExp(r'^\w+(?:Exception)?:\s*'),
      '',
    );
  }

  Future<void> close() async {
    _downloadController?.cancel();
    _engine?.cancelGeneration();
    await _downloadSubscription?.cancel();
    await _downloadController?.dispose();
    await _engine?.dispose();
  }

  @override
  void dispose() {
    _downloadController?.cancel();
    _engine?.cancelGeneration();
    unawaited(_downloadSubscription?.cancel());
    unawaited(_downloadController?.dispose());
    unawaited(_engine?.dispose());
    super.dispose();
  }
}
