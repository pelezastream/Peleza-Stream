import 'package:llamadart/llamadart.dart';

class LocalModel {
  const LocalModel({
    required this.id,
    required this.name,
    required this.description,
    required this.sourceUri,
    required this.sizeBytes,
    required this.minRamGb,
    required this.contextSize,
    required this.maxTokens,
    required this.license,
    this.sha256,
    this.supportsThinking = true,
    this.desktopOnly = false,
  });

  final String id;
  final String name;
  final String description;
  final String sourceUri;
  final int sizeBytes;
  final int minRamGb;
  final int contextSize;
  final int maxTokens;
  final String license;
  final String? sha256;
  final bool supportsThinking;
  final bool desktopOnly;

  ModelSource get source => ModelSource.parse(sourceUri);

  String get sizeLabel {
    final gib = sizeBytes / (1024 * 1024 * 1024);
    return gib >= 1
        ? '${gib.toStringAsFixed(gib >= 10 ? 1 : 2)} GB'
        : '${(sizeBytes / (1024 * 1024)).round()} MB';
  }
}

/// Curated models are downloaded from their publishers on first use. The app
/// never uploads prompts, conversations, or model output.
const List<LocalModel> modelCatalog = <LocalModel>[
  LocalModel(
    id: 'qwen35-08b-q4',
    name: 'Quick · Qwen 3.5 0.8B',
    description:
        'Fast, multilingual chat for most modern phones. Best for everyday '
        'questions and short answers.',
    sourceUri: 'hf://unsloth/Qwen3.5-0.8B-GGUF/Qwen3.5-0.8B-Q4_K_M.gguf',
    sizeBytes: 754903104,
    minRamGb: 3,
    contextSize: 4096,
    maxTokens: 1024,
    license: 'Apache-2.0 model family',
  ),
  LocalModel(
    id: 'gemma4-e2b-q4',
    name: 'Balanced · Gemma 4 E2B',
    description:
        'A stronger assistant for high-memory phones and ordinary computers. '
        'Recommended when answer quality matters more than speed.',
    sourceUri:
        'hf://unsloth/gemma-4-E2B-it-GGUF@90f9618340396838ee7ff5b0ba2da27da62953d3/gemma-4-E2B-it-Q4_K_S.gguf',
    sizeBytes: 3043932288,
    minRamGb: 8,
    contextSize: 8192,
    maxTokens: 2048,
    license: 'Gemma terms',
    sha256: '0a2fac16f388b4839f075dedb681357aec3e73a96bd66b413e462b6853550c99',
  ),
  LocalModel(
    id: 'gemma4-12b-q4',
    name: 'Smart · Gemma 4 12B',
    description:
        'Higher-quality reasoning and writing for capable desktop systems. '
        'This model is too large for typical phones.',
    sourceUri: 'hf://unsloth/gemma-4-12b-it-GGUF/gemma-4-12b-it-Q4_K_S.gguf',
    sizeBytes: 6764524960,
    minRamGb: 16,
    contextSize: 8192,
    maxTokens: 3072,
    license: 'Gemma terms',
    desktopOnly: true,
  ),
];
