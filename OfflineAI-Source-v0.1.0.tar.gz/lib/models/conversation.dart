enum MessageRole { user, assistant }

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.role,
    required this.text,
    required this.createdAt,
  });

  final String id;
  final MessageRole role;
  String text;
  final DateTime createdAt;

  bool get isUser => role == MessageRole.user;

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id,
    'role': role.name,
    'text': text,
    'createdAt': createdAt.toIso8601String(),
  };

  factory ChatMessage.fromJson(Map<String, Object?> json) => ChatMessage(
    id: json['id']! as String,
    role: MessageRole.values.byName(json['role']! as String),
    text: json['text']! as String,
    createdAt: DateTime.parse(json['createdAt']! as String),
  );
}

class Conversation {
  Conversation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    List<ChatMessage>? messages,
  }) : messages = messages ?? <ChatMessage>[];

  final String id;
  String title;
  final DateTime createdAt;
  DateTime updatedAt;
  final List<ChatMessage> messages;

  Map<String, Object?> toJson() => <String, Object?>{
    'id': id,
    'title': title,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
    'messages': messages
        .map((ChatMessage message) => message.toJson())
        .toList(),
  };

  factory Conversation.fromJson(Map<String, Object?> json) => Conversation(
    id: json['id']! as String,
    title: json['title']! as String,
    createdAt: DateTime.parse(json['createdAt']! as String),
    updatedAt: DateTime.parse(json['updatedAt']! as String),
    messages: (json['messages']! as List<Object?>)
        .map(
          (Object? value) =>
              ChatMessage.fromJson(value! as Map<String, Object?>),
        )
        .toList(),
  );
}
