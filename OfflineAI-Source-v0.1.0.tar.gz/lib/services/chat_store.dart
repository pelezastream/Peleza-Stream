import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/conversation.dart';

class ChatStore {
  static const String _conversationsKey = 'conversations.v1';
  static const String _selectedModelKey = 'selectedModel.v1';

  Future<List<Conversation>> loadConversations() async {
    final preferences = await SharedPreferences.getInstance();
    final encoded = preferences.getString(_conversationsKey);
    if (encoded == null || encoded.isEmpty) return <Conversation>[];

    try {
      final values = jsonDecode(encoded) as List<Object?>;
      return values
          .map(
            (Object? value) =>
                Conversation.fromJson(value! as Map<String, Object?>),
          )
          .toList();
    } on Object {
      // Keep startup recoverable if a previous development build wrote an
      // incompatible value. Model files are stored separately.
      return <Conversation>[];
    }
  }

  Future<void> saveConversations(List<Conversation> conversations) async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(
      _conversationsKey,
      jsonEncode(
        conversations
            .map((Conversation conversation) => conversation.toJson())
            .toList(),
      ),
    );
  }

  Future<String?> loadSelectedModelId() async {
    final preferences = await SharedPreferences.getInstance();
    return preferences.getString(_selectedModelKey);
  }

  Future<void> saveSelectedModelId(String? id) async {
    final preferences = await SharedPreferences.getInstance();
    if (id == null) {
      await preferences.remove(_selectedModelKey);
    } else {
      await preferences.setString(_selectedModelKey, id);
    }
  }
}
