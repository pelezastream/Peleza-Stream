# Offline AI

Offline AI is a private, ChatGPT-style assistant for Android, Windows, macOS,
and Linux. It downloads a local model once, then generates every response on
the device without an account, cloud inference, or an internet connection.

## Current capabilities

- Streaming, multi-turn chat with Markdown and code formatting
- Stop, copy, and regenerate controls
- Persistent conversations with rename and delete actions
- Resumable in-app model downloads and local cache management
- Three performance tiers for phones and computers
- Responsive mobile and desktop interface
- No telemetry, login, or prompt upload

The included catalog starts with a fast phone model, a stronger balanced model,
and a desktop model. Local models cannot match the largest hosted ChatGPT model;
answer quality depends on the model tier, available RAM, prompt, and device.

## Development

The project requires Flutter 3.44 or newer. The first build downloads the
pinned `llamadart` native runtime from its release artifacts.

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug --target-platform android-arm64
```

Desktop builds use the same source:

```bash
flutter build windows
flutter build macos
flutter build linux
```

macOS requires deployment target 14.0. Linux needs Flutter's normal GTK 3,
CMake, Ninja, and compiler prerequisites. Windows needs the current Visual C++
toolchain and redistributable. Enable Flutter's Swift Package Manager support
before a macOS build so the native llama.cpp package is linked:

```bash
flutter config --enable-swift-package-manager
flutter pub get
flutter build macos
```

## Offline validation

Build success proves that the UI and inference runtime are packaged. Before a
release, install the app on each target, download a model, enable airplane mode
or block network access, restart the app, and verify a new multi-turn reply.
Measure memory, speed, cancellation, and heat on representative phones.

See [architecture](docs/architecture.md) and [privacy](docs/privacy.md).

